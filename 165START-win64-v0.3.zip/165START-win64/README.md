# 165 START 🎲

**Sandbox matematika 3D — dari 1D sampai 5D.**
Sebuah dunia kecil yang bisa kamu ubah apa saja lewat panel parameter:
bentuk lahir dari persamaan, dan persamaannya bisa kamu sentuh langsung.

> *"Dalam kehidupan nyata, apapun adalah bentuk matematika."*

![preview](preview.png)

---

## Cara main (paling gampang)

**Windows:** klik dua kali `165START.exe` → game terbuka di jendelanya sendiri.
(Tanpa install apa pun. Tanpa internet.)

**Cara manual / Linux/Mac:** klik dua kali `index.html` — atau klik kanan → *Open with* → Chrome/Edge.

## Tombol

| Tombol | Fungsi |
|---|---|
| `W A S D` | Jalan / terbang bebas |
| `Mouse` | Lihat sekeliling |
| `Spasi` / `C` | Naik / turun |
| `Shift` | Lari (lebih cepat) |
| `Tab` | Buka / tutup panel parameter |
| `1`–`5` | Ganti dimensi hiperkubus (1D…5D) |
| `R` | Kembali ke posisi awal |

## Yang bisa kamu ubah (panel kiri)

- **Dunia** — kecepatan jalan, jarak kabut.
- **Objek matematika** — pilih dari **15 rumus**: Torus, Bola, Gelombang, Hiperboloid, Spiral, Lissajous, **Mandelbrot**, **Julia**, **Burning Ship**, **Newton**, **Sierpinski**, **Mobius**, **Superelipsoid**, **Mawar**, **Fibonacci**. Lalu atur **ukuran, tebal, frekuensi, amplitudo, twist, detail mesh, iterasi fraktal, eksponen bentuk, tingkat logam, kekasaran, wireframe, flat shading**.
- **Spons Menger** — fraktal 3D: atur level rekursi (0–3, level 3 = 8.000 kubus) dan ukurannya.
- **Hiperkubus 1D → 5D** — dimensi, ukuran, kecepatan rotasi, jarak proyeksi 4D.
- **Tampilan** — cahaya matahari, paparan cahaya.

Semua angka di panel itu **parameter matematika yang sesungguhnya** — mengubahnya mengubah persamaan, dan persamaan mengubah wujud bendanya. Di rumus *Julia*, memutar slider **twist** = memutar konstanta c → setiap sudut menghasilkan fraktal yang berbeda.

## Isi folder

```
165START.exe      → pemutar game untuk Windows (klik dua kali)
index.html        → seluruh game (bisa dibuka di browser mana pun)
three.min.js      → mesin 3D (ringan, offline)
preview.png       → tampilan game
README.md         → file ini
```

Game-nya sendiri hanya ± 1 MB (sangat ringan). Paket Windows lengkap (`165START-win64-v0.3.zip`, ± 0,5 MB) berisi semuanya termasuk aplikasi pemutar.

## Untuk yang suka ngoprek

Semua kode ada di `index.html`. Cari tulisan **`PARAM`** untuk mulai mengubah:
ganti angka, simpan file, refresh browser. Tidak perlu compile apa pun.

## Peta jalan (roadmap)

- **v0.1** — dunia 3D, gerak bebas, panel parameter, hiperkubus 1D–5D, efek CRT retro, latar aero. ✅
- **v0.2** — fraktal: Mandelbrot, Julia, Spons Menger, plus Mobius, Superelipsoid, Fibonacci; aplikasi Windows (`165START.exe` 36 KB). ✅
- **v0.3 (sekarang)** — tambah **Burning Ship, Newton, Sierpinski, Mawar** → 15 rumus total. ✅
- **v0.4** — simpan & muat kreasi (JSON), medan vektor, permukaan minimal.
- **v0.5** — objek yang saling berinteraksi (gravitasi, tumbukan sederhana).
- **v1.0** — mode edukasi: tantangan matematika, penjelasan rumus di dalam game, mode multiplayer sederhana.

---

Dibuat dengan semangat: *matematika itu nyata, bisa dipegang, dan bisa dimainkan.*
